const form = require("../models/blog");
const student = require("../models/details");
const path = require('path');
const bodyParser = require('body-parser');
var fs = require('fs');
let name = "Blog";

exports.getPost = async (req, res, next) => {
  try {
  const result = await form.find({}).select('title');
  console.log(result)
    res.render('home', {
      pageTitle: 'Home | Blog post',
      newPost: 'New Post',
      back: '',
      edit: '',
      name: name,
      id: '',
      value: 1,
      del: '',
      result: result,
      path: '/admin/add-product'
    });
  }catch(error){
    console.log(console.log(error));
  }
  };

  exports.getNewPost = (req, res, next) => {
    
    res.render('newpost', {
      pageTitle: 'Form | New post',
      newPost: '',
      edit: '',
      id: '',
      del: '',
      value: 1,
      back: 'back to home',
      path: '/admin/add-product'
    });
  };

  exports.getInfo = async (req, res, next) => {
    var id = req.params.id;
    
    console.log(id)
    try {
    var ObjectId = require('mongoose').Types.ObjectId;
    const result = await form.find({"_id" :ObjectId(id.trim())});
    console.log(result);
   
    
    res.render('info', {
      pageTitle: 'Form | New post',
      id:id,
      newPost: '',
      edit: '',
      del: 'Delete',
      back: 'Home',
      data: result,
      path: '/admin/add-product'
    });
  }catch(error){
    console.log(console.log(error));
  }
  };

  exports.getHomePost = async (req, res, next) => {
    try {
      if(!req.files)
    res.send("dont choose file")
    else{
    console.log(req.files)
    var imagefile=req.files.file
    var imagename=req.files.file.name
    imagefile.mv(path.join(__dirname, '../public/uploads')+imagename,function(err){
        if (err){
            res.send(err)
        }
    })
    }

    const blogDate = new form({
      title: req.body.title,
      categories: req.body.categories,
      content: req.body.content,
      image: imagename
    });
    const createBlog = await blogDate.save();
    console.log(createBlog)
    res.redirect('/home');
  }catch(error) {
    res.status(400).send(error);
  };
  };
  
  exports.deletePost = async (req, res, next) => {
    var id = req.params.id.trim();
    console.log(id)
    try {
      var ObjectId = require('mongoose').Types.ObjectId;
      const result = await form.deleteMany({"_id" :ObjectId(id)});
      console.log(result);
    res.redirect('/home');
  }catch(error) {
    res.status(400).send(error);
  };
  };

  exports.editPost = async (req, res, next) => {
    var id = req.params.id.trim();
    console.log(id+"eeeee");
    
    try {
        
        res.render('newpost',{
          value: 0,
          id: id,
          pageTitle: 'Edit blog',
          path: '/admin/add-product',
          newPost: '',
          back: 'back to home',
          edit: '',
          del: ''
        })
      }catch(error) {
    res.status(400).send(error);
  };
  };

  exports.editNewPost = async (req, res, next) => {
    var id = req.params.id.trim();
    console.log("Welcome to edit section")
    console.log(id)
    console.log(req.body)
    try {
        var ObjectId = require('mongoose').Types.ObjectId;
        const result = await form.update({"_id" :ObjectId(id)},
        {$set: {title : req.body.title,
          categories: req.body.categories,
          content: req.body.content}});
        console.log(result);
        res.redirect('/home');
      }catch(error) {
    res.status(400).send(error);
  };
  };
  
  exports.getlogin = async (req, res, next) => {
    res.render('login',{
    });
  
  };

  exports.postlogin = async (req, res, next) => {
    Eemail=req.body.email;
    Ppassword=req.body.password;
    console.log(Ppassword);
    const axios = require('axios')

axios
  .post('http://localhost:3000/api/user/login', {
    email: Eemail,
    password: Ppassword
  })
  .then(response => {
    if(response.data.length>30)
    {
      res.redirect("/home");
    }
    else{
      res.send("wrong password");
    }
    console.log(typeof res.data);
    console.log(`statusCode: ${response.data}`);
    //console.log(res)
  })
  .catch(error => {
    console.error(error)
  })
  };

  exports.getRegister = async (req, res, next) => {
    res.render('register',{
    });
  
  };

  exports.postRegister = async (req, res, next) => {
    Eemail=req.body.email;
    Ppassword=req.body.password;
    Nname=req.body.name;
    
    console.log(Ppassword);
    const axios = require('axios')

axios
  .post('http://localhost:3000/api/user/register', {
    name: Nname,
    email: Eemail,
    password: Ppassword
  })
  .then(response => {
  
   if(response.data=="email already exist") {
    res.send("email alredy exits");
    }
    else if(response.data=='"email" must be a valid email'){
      res.send('"email" must be a valid email');
      
    }else if(response.data=='"name" length must be at least 5 characters long'){
      res.send('"name" length must be at least 5 characters long');
      console.log("ggggg");
    }else{
      res.redirect("/login");
    }
    
   
    console.log(typeof response.data);
    console.log(`statusCode: ${response.data}`)
    //console.log(res)
  })
  .catch(error => {
    console.error(error)
  })
  };
 

  exports.getDetails = async (req, res, next) => {
    res.render('detail',{
    });
  
  };

  exports.postDetails = async (req, res, next) => {
    try {
    console.log(req.body);
    var STD_NAME = req.body.STD_NAME;
    var STD_CID = req.body.STD_CID;
    var S_EMAIL = req.body.S_EMAIL;
    var G_NAME = req.body.G_NAME;
    var G_CONTECT = req.body.G_CONTECT;
    var C_SELECTION = req.body.C_SELECTION;
    var SLOT = req.body.SLOT;
    var FRIEND_NAME = req.body.FRIEND_NAME;
    var FRIEND_CONTECT = req.body.FRIEND_CONTECT;
    var FRIEND_EMAIL = req.body.FRIEND_EMAIL;
    
    
    const studentDate = new student({
      STD_NAME : req.body.STD_NAME,
      STD_CID : req.body.STD_CID,
      S_EMAIL : req.body.S_EMAIL,
      G_NAME : req.body.G_NAME,
      G_CONTECT : req.body.G_CONTECT,
      C_SELECTION : req.body.C_SELECTION,
      SLOT : req.body.SLOT,
      FRIEND_NAME : req.body.FRIEND_NAME,
      FRIEND_CONTECT : req.body.FRIEND_CONTECT,
      FRIEND_EMAIL : req.body.FRIEND_EMAIL

    });
    const std = await studentDate.save();
    console.log(std);
  }catch(error) {
    res.status(400).send(error);
  };
  };