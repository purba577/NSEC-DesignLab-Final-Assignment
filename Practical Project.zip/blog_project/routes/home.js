const path = require('path');
const bodyParser = require('body-parser');
const express = require('express');
const urlencoderParser = bodyParser.urlencoded({ extended: false});
const postController = require('../controllers/homeblog.js');

const router = express.Router();


router.get('/login', postController.getlogin);
router.post('/login', postController.postlogin);
router.get('/register', postController.getRegister);
router.post('/register', postController.postRegister);

router.get('/home', postController.getPost);
router.post('/home',urlencoderParser, postController.getHomePost);

router.get('/new', postController.getNewPost);
router.get('/info/:id', postController.getInfo);
router.get('/delete/:id', postController.deletePost);

router.get('/detail', postController.getDetails);
router.post('/details', postController.postDetails);


module.exports = router;