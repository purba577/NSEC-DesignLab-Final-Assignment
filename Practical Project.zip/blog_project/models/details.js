const mongoose = require('mongoose')
require('../util/connection')
const StudentDate = new mongoose.Schema({

    STD_NAME: {
        type: String,
        required : true
    },
    STD_CID : {
        type: String,
        required : true
    },
    S_EMAIL : {
        type: String,
        required : true
    },
    G_NAME : {
        type: String,
        required : true
    },
    G_CONTECT : {
       type: String,
       required : true
    },
    C_SELECTION : {
      type: String,
      required : true
    },
    SLOT : {
     type: String,
     required : true
     },
     FRIEND_NAME : {
    type: String,
    required : true
    },
    FRIEND_CONTECT : {
        type: String,
        required : true
    },
    FRIEND_EMAIL : {
        type: String,
        required : true
    }
    
});

const Playlist = new mongoose.model("StudentApp",StudentDate);
module.exports = Playlist;