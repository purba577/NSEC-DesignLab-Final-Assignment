const path = require('path');
const port = process.env.PORT || 3002;




const express = require('express');
const bodyParser = require('body-parser');

const errorController = require('./controllers/error');

const app = express();

app.set('view engine', 'ejs');
app.set('views', 'views');
app.use(express.urlencoded({extended:false}));

const homeRoutes = require('./routes/home');


app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

const upload=require("express-fileupload");
app.use(upload())
app.use(homeRoutes);

app.use(errorController.get404);

app.listen(port,function(err){
    if (err) console.log(err);
    console.log("Server listening on PORT", port);
});
